function display()
{
    document.getElementById("examplebutton").innerText = "This is the Java part ☃️"
}